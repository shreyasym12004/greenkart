<div class="footer">
            
            <div>
                <strong>Copyright @</strong> Grocery Shop &copy; <?php echo date("Y"); ?>
            </div>
        </div>