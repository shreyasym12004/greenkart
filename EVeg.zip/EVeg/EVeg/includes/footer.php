 <footer class="footer">
               <div class="container">
                  <!-- top footer statrs -->
                  <div class="row top-footer">
                     <div class="col-xs-12 col-sm-3 footer-logo-block color-gray">
                        <a href="index.php" style="font-size:20px;">Grocery Shop </a><br /> <span>Order Delivery  </span> 
                     </div>
                     <div class="col-xs-12 col-sm-2 about color-gray">
                        <h5>About Us</h5>
                        <ul>
                           <li><a href="about-us.php">About us</a> </li>
                           <li><a href="contact.php">Contact us</a> </li>
                       
                        </ul>
                     </div>
                     <div class="col-xs-12 col-sm-2 how-it-works-links color-gray">
                        <h5>My Account</h5>
                        <ul>
                           <li><a href="#">My Profile</a> </li>
                           <li><a href="#">My Cart</a> </li>
                           <li><a href="#">My Order</a> </li>
                        
                        </ul>
                     </div>
        <div class="col-xs-12 col-sm-2 how-it-works-links color-gray">
                        <h5>Track Order </h5>
                        <ul>
                           <li><a href="track-order-on.php">Track Order </a> </li>
                       
                        
                        </ul>
                     </div>

                
                <div class="col-xs-12 col-sm-2 how-it-works-links color-gray">
                        <h5>Admin </h5>
                        <ul>
                           <li><a href="admin" target="_blank">Login </a> </li>
                       
                        
                        </ul>
                     </div>
                
                
                  </div>
                  <!-- top footer ends -->
  
                  <!-- bottom footer ends -->
               </div>
            </footer>